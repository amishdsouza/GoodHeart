<?php
$apiKey = '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';
 ?>
